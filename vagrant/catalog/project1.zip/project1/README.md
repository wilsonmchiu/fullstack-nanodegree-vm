Insert python3 news.py to run the program

The first 2 queries were experiments to find out how to use WHERE and JOIN statements.
The last one gets the total number of errors and divides by the total number of requests.